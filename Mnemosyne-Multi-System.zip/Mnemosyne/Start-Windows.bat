@echo off
title Mnemosyne
cd /d "%~dp0"
call "%~dp0files\windows\start.bat" %*
if errorlevel 1 pause
