#!/usr/bin/env bash
# Mnemosyne for macOS. Double-click this file (or run: bash Start-macOS.command)
cd "$(dirname "$0")" || exit 1
bash files/macos/start.sh "$@"
status=$?
if [ "$status" -ne 0 ]; then
    echo
    read -r -p "Press Enter to close..." _ || true
fi
exit $status
