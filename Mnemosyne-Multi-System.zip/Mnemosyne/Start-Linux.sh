#!/usr/bin/env bash
# Mnemosyne for Linux. Run:  bash Start-Linux.sh
cd "$(dirname "$0")" || exit 1
bash files/linux/start.sh "$@"
status=$?
if [ "$status" -ne 0 ]; then
    echo
    read -r -p "Press Enter to close..." _ || true
fi
exit $status
