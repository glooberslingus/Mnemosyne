# Mnemosyne

A portable video archiver. Choose **Channel archive** to save a YouTube channel's videos, or **Single video / other supported site** to save one video URL supported by yt-dlp.

Mnemosyne needs no installer. Copy the whole folder to another computer and run it there. It requires Python 3.9 or newer and, for full YouTube support, Deno 2.3 or newer or Node.js 22 or newer.

## Start

1. Extract the ZIP.
2. Run the launcher for your computer:
   - **Windows:** double-click `Start-Windows.bat`
   - **macOS:** double-click `Start-macOS.command`
   - **Linux:** run `bash Start-Linux.sh` in a terminal
3. Your browser opens on a free local port. The first time, click **Download tools** to fetch yt-dlp and ffmpeg for your system. Install Deno or Node.js if your computer does not already have a supported JavaScript runtime.

Close the terminal window, or choose **Quit** in the app, to stop it.

## Use the app

1. Choose a channel archive or a single video URL. Channel links can use `youtube.com/@handle`, `/channel/UC...` or `/c/Name`.
2. Press **Check** to preview the channel or video, then choose the basic download settings.
3. Press **Download**. Audio is included in video files, and English subtitles are embedded when available. Progress, speed and time remaining update live; **Pause** and **Cancel** are always available.

The **Auto / Light / Dark** switch at the top changes the appearance. Auto follows your system.

Each channel gets its own folder:

```
downloads/<Channel Name>/
    archive.txt                  what has already been saved
    My Video [id]/               one folder per video
        My Video [id].mp4        English subtitles and cover image embedded
    Another Video [id]/
        ...
```

Single-video downloads go in `downloads/Videos/`. In **Advanced settings**, turn off **One subfolder per video** to put each video directly in its channel folder (or directly in `Videos` for single-video downloads); keep it on to give each video its own folder.

The default download combines video and audio and embeds English subtitles and the thumbnail into supported media files, leaving no separate per-video `.jpg` or subtitle file. Turn off **Thumbnail in video** to save a separate thumbnail. To save separate subtitle files, enable **Subtitles** in **Also save**. Open **Advanced settings** for codec and container choices, YouTube sign-in, optional channel artwork, channel extras, and the option to keep the pre-merge video track. The **File names** option sets the file name and, when enabled, the per-video folder name.

Enable **Slower request pacing** to pause between YouTube data requests while scanning a channel and wait a random 5–10 seconds between video downloads. This can help reduce rate limiting on large channel archives; it does not guarantee that YouTube will not limit requests.

For video downloads, **Downscale after download** caps the output height (for example, 720p or 480p) while keeping the original aspect ratio. Choose an encoder from the **Video codec** or **Audio codec** dropdown, or select **Custom…** to enter another FFmpeg encoder name. **Auto detect** choices for H.264, HEVC and AV1 probe the bundled FFmpeg to find a working encoder. **Hardware preference** controls which hardware encoders are tried first; CPU is used as a fallback. ProRes, MPEG-2, MPEG-4 Part 2 and uncompressed raw video are also available. ProRes switches the container to MOV, while MPEG-2 and raw video switch to MKV. **Default / copy** preserves yt-dlp's normal stream-copy behavior. Codec and downscale processing uses FFmpeg during yt-dlp's merge step, so it applies when the source video and audio are separate streams. Codec/container combinations must be supported by FFmpeg and the chosen container.

## Resuming and retrying

`archive.txt` records every finished video, so running the same channel again skips what is already saved. You can stop at any time and continue later.

Videos that cannot be saved (private, age-restricted, members-only, region-locked) are skipped and listed with a plain-English reason. Press **Retry failed** to try them again.

## What is in the folder

```
Mnemosyne/
    Start-Windows.bat        launchers: run the one for your computer
    Start-macOS.command
    Start-Linux.sh
    downloads/               your archive (created on first run)
    files/
        README.md
        app/                 the program: mnemosyne.py and mnemosyne.html
        bin/                 yt-dlp and ffmpeg (downloaded on first run)
        data/                settings.json, cache and logs
        windows/  macos/  linux/    the start scripts for each system
```

Mnemosyne writes only inside this folder. It does not touch the registry, your home folder or your PATH.

Use **Update yt-dlp** in the app if downloads start failing. YouTube changes often and yt-dlp needs regular updates.

## Uninstall

There is nothing to uninstall. Delete the folder. Your `downloads` folder is inside it, so move it out first if you want to keep your archive.

## If something goes wrong

- **Windows:** if SmartScreen appears, choose **More info > Run anyway** if you trust the ZIP you downloaded. If Python is not found, install it from python.org and tick **Add python.exe to PATH**.
- **macOS:** if the launcher is blocked, Control-click it, choose **Open**, then choose **Open** again. On an Apple Silicon Mac, ffmpeg is an Intel build and needs Rosetta once: run `softwareupdate --install-rosetta --agree-to-license` in Terminal.
- **Linux:** Mnemosyne uses `python3`. On Debian or Ubuntu: `sudo apt install python3`. It needs a 64-bit x86 or ARM system with glibc, so Alpine Linux is not supported. If no browser opens, open the address printed in the terminal.
- **USB drives:** some drives and network folders block programs from running. If the app says the tools cannot run from this location, copy the folder to the computer's own disk. Use exFAT or NTFS rather than FAT32, which cannot hold files over 4 GB.
- **Errors:** details are saved in `files/data/logs`. Delete `files/bin` and press **Download tools** to reinstall the tools.

Only download content you have the right to save.
