@echo off
setlocal
set "APP=%~dp0..\app\mnemosyne.py"

if not exist "%APP%" (
    echo Could not find files\app\mnemosyne.py.
    echo Please extract the whole zip first, then run Start-Windows.bat again.
    exit /b 1
)

set "PY="
for %%C in ("py -3" "python" "python3") do (
    if not defined PY (
        %%~C -c "import sys; sys.exit(0 if sys.version_info >= (3, 9) else 1)" >nul 2>nul && set "PY=%%~C"
    )
)

if not defined PY (
    echo Python 3.9 or newer was not found.
    echo.
    echo Install it from https://www.python.org/downloads/windows/
    echo and tick Add python.exe to PATH in the installer.
    echo Then run Start-Windows.bat again.
    exit /b 1
)

%PY% "%APP%" %*
exit /b %errorlevel%
