#!/usr/bin/env python3
"""Mnemosyne: a portable video archiver for channels and individual URLs.

Standard library only (Python 3.9+). Serves a small local web UI and drives
the yt-dlp and ffmpeg programs that it downloads into files/bin.

Everything Mnemosyne writes stays inside its own folder:
  downloads/            the archive (next to the Start-* launchers)
  files/bin/            yt-dlp and ffmpeg
  files/data/           settings.json, cache and logs
"""
from __future__ import annotations

import json
import os
import platform
import re
import shutil
import signal
import socket
import ssl
import subprocess
import sys
import tarfile
import threading
import time
import traceback
import urllib.error
import urllib.request
import urllib.parse
import webbrowser
import zipfile
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

if sys.version_info < (3, 9):
    sys.exit("Python 3.9 or newer is required.")

APP_DIR = Path(__file__).resolve().parent      # files/app
FILES_DIR = APP_DIR.parent                      # files
ROOT_DIR = FILES_DIR.parent                     # the portable Mnemosyne folder
BIN_DIR = FILES_DIR / "bin"
DATA_DIR = FILES_DIR / "data"
TMP_DIR = BIN_DIR / "_tmp"
CACHE_DIR = DATA_DIR / "cache"
LOG_DIR = DATA_DIR / "logs"
DOWNLOADS_DIR = ROOT_DIR / "downloads"
SETTINGS_FILE = DATA_DIR / "settings.json"
INDEX_FILE = APP_DIR / "mnemosyne.html"

IS_WIN = os.name == "nt"
EXE = ".exe" if IS_WIN else ""
NOWIN = 0x08000000 if IS_WIN else 0  # CREATE_NO_WINDOW
YTDLP = BIN_DIR / ("yt-dlp" + EXE)
FFMPEG = BIN_DIR / ("ffmpeg" + EXE)
FFPROBE = BIN_DIR / ("ffprobe" + EXE)

# --------------------------------------------------------------------------
# Settings
# --------------------------------------------------------------------------

QUALITIES = {"best": None, "2160": 2160, "1440": 1440, "1080": 1080,
             "720": 720, "480": 480, "360": 360, "audio": None}
CONTAINERS = ("mp4", "mkv", "webm", "mov")
HARDWARE_PREFERENCES = ("auto", "cpu", "nvidia", "amd", "intel")
AUDIO_QUALITIES = ("best", "256", "192", "128")
AUDIO_FORMATS = ("mp3", "m4a", "opus")
THUMB_FORMATS = ("jpg", "png")
THEMES = ("auto", "light", "dark")
YOUTUBE_BROWSERS = ("", "chrome", "edge", "firefox", "brave", "chromium", "opera", "vivaldi", "safari")
FILENAMES = {
    "title_id": "%(title)s [%(id)s]",
    "date_title_id": "%(upload_date>%Y-%m-%d)s - %(title)s [%(id)s]",
    "title": "%(title)s",
    "date_title": "%(upload_date>%Y-%m-%d)s - %(title)s",
    "id": "%(id)s",
}
EXTRA_KEYS = ("metadata", "subs", "shorts", "live", "keep_video", "channel_art")

DEFAULT_SETTINGS = {
    "url": "",
    "youtube_api_key": "",
    "youtube_browser": "",
    "download_mode": "channel",
    "quality": "best",
    "container": "mp4",
    "embed_subs": True,
    "embed_thumbnail": True,
    "video_codec": "",
    "hardware_preference": "auto",
    "audio_codec": "",
    "max_height": "",
    "slow_pacing": False,
    "audio_quality": "best",
    "audio_format": "mp3",
    "thumb_format": "jpg",
    "filename": "title_id",
    "video_subfolders": True,
    "theme": "auto",
    "extras": {k: False for k in EXTRA_KEYS},
}


def clean_settings(raw) -> dict:
    """Return a fully valid settings dict, falling back to defaults."""
    raw = raw if isinstance(raw, dict) else {}
    s = json.loads(json.dumps(DEFAULT_SETTINGS))

    def pick(key, allowed):
        v = raw.get(key)
        if v in allowed:
            s[key] = v

    pick("quality", QUALITIES)
    pick("container", CONTAINERS)
    pick("download_mode", ("channel", "video"))
    pick("hardware_preference", HARDWARE_PREFERENCES)
    for key in ("video_codec", "audio_codec"):
        value = raw.get(key, "")
        # Codec names are passed as a single ffmpeg argument.
        if isinstance(value, str) and (not value or re.fullmatch(r"[A-Za-z0-9_.+-]{1,64}", value)):
            s[key] = value
    value = raw.get("max_height", "")
    if value in ("", None):
        s["max_height"] = ""
    elif str(value).isdigit() and 144 <= int(value) <= 4320:
        s["max_height"] = str(int(value))
    pick("audio_quality", AUDIO_QUALITIES)
    pick("audio_format", AUDIO_FORMATS)
    pick("thumb_format", THUMB_FORMATS)
    pick("filename", FILENAMES)
    s["video_subfolders"] = bool(raw.get("video_subfolders", True))
    pick("theme", THEMES)
    if isinstance(raw.get("url"), str):
        s["url"] = raw["url"].strip()[:500]
    s["embed_subs"] = bool(raw.get("embed_subs", True))
    s["embed_thumbnail"] = bool(raw.get("embed_thumbnail", True))
    api_key = raw.get("youtube_api_key", "")
    if isinstance(api_key, str) and len(api_key) <= 256 and re.fullmatch(r"[A-Za-z0-9_-]*", api_key):
        s["youtube_api_key"] = api_key
    pick("youtube_browser", YOUTUBE_BROWSERS)
    s["slow_pacing"] = bool(raw.get("slow_pacing", False))
    ex = raw.get("extras")
    if isinstance(ex, dict):
        for k in EXTRA_KEYS:
            s["extras"][k] = bool(ex.get(k))
    return s


def load_settings() -> dict:
    try:
        return clean_settings(json.loads(SETTINGS_FILE.read_text(encoding="utf-8")))
    except Exception:
        return clean_settings({})


def save_settings(settings: dict) -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    tmp = SETTINGS_FILE.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(settings, indent=2), encoding="utf-8")
    os.replace(tmp, SETTINGS_FILE)


# --------------------------------------------------------------------------
# Shared state + change notification (feeds Server-Sent Events)
# --------------------------------------------------------------------------

class UserError(Exception):
    """An error whose message is safe and useful to show in the UI."""


class Hub:
    def __init__(self):
        self.cond = threading.Condition()
        self.version = 0
        self.state = {
            "tools": {"ytdlp": False, "ffmpeg": False, "ytdlp_version": "",
                      "busy": False, "message": "", "percent": 0, "error": ""},
            "job": {"status": "idle", "message": "", "channel": None,
                    "overall": {"index": 0, "total": 0},
                    "counts": {"done": 0, "skipped": 0, "failed": 0},
                    "current": None, "failures": [], "folder": ""},
            "settings": load_settings(),
            "platform": {"os": sys.platform, "python": platform.python_version()},
        }

    def update(self, section: str, **kw):
        with self.cond:
            self.state[section].update(kw)
            self.version += 1
            self.cond.notify_all()

    def snapshot(self):
        with self.cond:
            return json.dumps(self.state), self.version

    def wait(self, last: int, timeout: float) -> int:
        with self.cond:
            if self.version == last:
                self.cond.wait(timeout)
            return self.version


HUB = Hub()


def log_error(text: str) -> None:
    try:
        LOG_DIR.mkdir(parents=True, exist_ok=True)
        with open(LOG_DIR / "errors.log", "a", encoding="utf-8") as f:
            f.write(time.strftime("%Y-%m-%d %H:%M:%S ") + text + "\n")
    except OSError:
        pass


# --------------------------------------------------------------------------
# Plain-English error messages
# --------------------------------------------------------------------------

_RULES = [
    ("not a bot", "YouTube is limiting requests right now. Wait a while, then use Retry."),
    ("429", "YouTube is limiting requests right now. Wait a while, then use Retry."),
    ("too many requests", "YouTube is limiting requests right now. Wait a while, then use Retry."),
    ("private video", "This video is private."),
    ("confirm your age", "This video is age-restricted and needs a signed-in account."),
    ("age-restricted", "This video is age-restricted and needs a signed-in account."),
    ("in your country", "This video is not available in your region."),
    ("geo restrict", "This video is not available in your region."),
    ("members-only", "This video is for channel members only."),
    ("join this channel", "This video is for channel members only."),
    ("premieres in", "This is a scheduled premiere or stream that has not started yet."),
    ("live event will begin", "This is a scheduled stream that has not started yet."),
    ("will begin in", "This is a scheduled stream that has not started yet."),
    ("copyright", "This video was removed after a copyright claim."),
    ("terminated", "The account that posted this video was closed."),
    ("video unavailable", "This video is unavailable or has been removed."),
    ("this video is unavailable", "This video is unavailable or has been removed."),
    ("has been removed", "This video has been removed."),
    ("unable to connect to proxy", "Could not reach YouTube. This network may be blocking it."),
    ("tunnel connection failed", "Could not reach YouTube. This network may be blocking it."),
    ("unable to connect", "Could not reach YouTube. Check your internet connection."),
    ("getaddrinfo", "Could not reach YouTube. Check your internet connection."),
    ("name resolution", "Could not reach YouTube. Check your internet connection."),
    ("network is unreachable", "Could not reach YouTube. Check your internet connection."),
    ("timed out", "The connection timed out. Check your internet connection."),
    ("connection reset", "The connection was interrupted. Check your internet connection."),
    ("unable to download webpage", "Could not reach YouTube. Check your internet connection."),
    ("certificate", "A secure connection could not be verified on this computer."),
    ("does not exist", "That channel could not be found."),
    ("404", "That channel could not be found."),
]


def friendly(msg: str, fallback: str) -> str:
    low = (msg or "").lower()
    for needle, text in _RULES:
        if needle in low:
            return text
    return fallback


# --------------------------------------------------------------------------
# Tools: yt-dlp and ffmpeg downloads into ./bin
# --------------------------------------------------------------------------

def child_env() -> dict:
    env = dict(os.environ)
    TMP_DIR.mkdir(parents=True, exist_ok=True)
    env["PYTHONUTF8"] = "1"
    env["PYTHONIOENCODING"] = "utf-8"
    # Keep PyInstaller's unpack folder inside the app folder, not the system temp.
    for k in ("TMPDIR", "TEMP", "TMP"):
        env[k] = str(TMP_DIR)
    env["PATH"] = str(BIN_DIR) + os.pathsep + env.get("PATH", "")
    return env


def tool_plan():
    """Work out which downloads this operating system and CPU need.

    "ffmpeg" is a list of alternative sources; each source is a list of
    (archive kind, url) pairs that together provide ffmpeg and ffprobe.
    """
    machine = platform.machine().lower()
    arm = machine in ("arm64", "aarch64")
    intel = machine in ("x86_64", "amd64")
    yt = "https://github.com/yt-dlp/yt-dlp/releases/latest/download/"
    btbn = "https://github.com/BtbN/FFmpeg-Builds/releases/download/latest/"
    ffb = "https://github.com/ffbinaries/ffbinaries-prebuilt/releases/download/v6.1/"
    if sys.platform.startswith("win"):
        if not (arm or intel):
            raise UserError("This version of Windows is not supported. Mnemosyne needs a 64-bit PC.")
        arch = "winarm64" if arm else "win64"
        return {"ytdlp": yt + "yt-dlp.exe",
                "ffmpeg": [[("zip", btbn + "ffmpeg-master-latest-%s-gpl.zip" % arch)]]}
    if sys.platform == "darwin":
        ev = "https://evermeet.cx/ffmpeg/getrelease/"
        return {"ytdlp": yt + "yt-dlp_macos",
                "ffmpeg": [[("zip", ffb + "ffmpeg-6.1-macos-64.zip"), ("zip", ffb + "ffprobe-6.1-macos-64.zip")],
                           [("zip", ev + "ffmpeg/zip"), ("zip", ev + "ffprobe/zip")]]}
    if sys.platform.startswith("linux"):
        if not (arm or intel):
            raise UserError("This processor type is not supported. Mnemosyne needs a 64-bit x86 or ARM computer.")
        return {"ytdlp": yt + ("yt-dlp_linux_aarch64" if arm else "yt-dlp_linux"),
                "ffmpeg": [[("tar.xz", btbn + "ffmpeg-master-latest-%s-gpl.tar.xz" % ("linuxarm64" if arm else "linux64"))]]}
    raise UserError("This operating system is not supported. Mnemosyne runs on Windows, macOS and Linux.")


def _curl_download(url: str, dest: Path) -> bool:
    """Fallback when Python cannot verify certificates (common on fresh macOS Python installs)."""
    curl = shutil.which("curl")
    if not curl:
        return False
    r = subprocess.run([curl, "-L", "--fail", "-sS", "-o", str(dest), url], capture_output=True, creationflags=NOWIN)
    return r.returncode == 0 and dest.exists()


def http_download(url: str, dest: Path, on_progress) -> None:
    req = urllib.request.Request(url, headers={"User-Agent": "Mnemosyne/1.0"})
    try:
        with urllib.request.urlopen(req, timeout=60) as r, open(dest, "wb") as f:
            total = int(r.headers.get("Content-Length") or 0)
            got = 0
            while True:
                chunk = r.read(1 << 16)
                if not chunk:
                    break
                f.write(chunk)
                got += len(chunk)
                on_progress(got, total)
    except urllib.error.URLError as e:
        if isinstance(getattr(e, "reason", None), ssl.SSLError) and _curl_download(url, dest):
            on_progress(dest.stat().st_size, dest.stat().st_size)
            return
        raise


def _make_exec(path: Path) -> None:
    if not IS_WIN:
        try:
            path.chmod(path.stat().st_mode | 0o755)
        except OSError:
            pass  # some drive formats (FAT, exFAT) have no permission bits


def _extract_ffmpeg(kind: str, archive: Path) -> None:
    wanted = {"ffmpeg" + EXE, "ffprobe" + EXE}
    found = 0
    if kind == "zip":
        with zipfile.ZipFile(archive) as z:
            for info in z.infolist():
                base = Path(info.filename).name
                if base in wanted and not info.is_dir():
                    with z.open(info) as src, open(BIN_DIR / base, "wb") as dst:
                        shutil.copyfileobj(src, dst)
                    _make_exec(BIN_DIR / base)
                    found += 1
    else:
        with tarfile.open(archive, "r:xz") as t:
            for m in t:
                base = Path(m.name).name
                if m.isfile() and base in wanted:
                    src = t.extractfile(m)
                    with open(BIN_DIR / base, "wb") as dst:
                        shutil.copyfileobj(src, dst)
                    _make_exec(BIN_DIR / base)
                    found += 1
    if not found:
        raise UserError("The ffmpeg download did not contain the expected files.")


def tools_present() -> dict:
    return {"ytdlp": YTDLP.exists(), "ffmpeg": FFMPEG.exists() and FFPROBE.exists()}


def _explain_launch_failure(exe: Path) -> str:
    if exe.stem.startswith("ff") and sys.platform == "darwin" and platform.machine().lower() in ("arm64", "aarch64"):
        return ("ffmpeg here is built for Intel Macs, so this Mac needs Rosetta once. Open Terminal and run: "
                "softwareupdate --install-rosetta --agree-to-license")
    return ("%s cannot run from this location. A USB drive or network folder can block programs from running. "
            "Copy the whole Mnemosyne folder to this computer's own disk and try again." % exe.stem)


def probe_tools():
    """Run each installed tool once. Returns (yt-dlp version, problem text)."""
    version, problem = "", ""
    checks = ((YTDLP, ["--ignore-config", "--cache-dir", str(CACHE_DIR), "--version"]),
              (FFMPEG, ["-version"]), (FFPROBE, ["-version"]))
    for exe, args in checks:
        if not exe.exists():
            continue
        try:
            r = subprocess.run([str(exe)] + args, capture_output=True, timeout=90,
                               env=child_env(), creationflags=NOWIN)
        except subprocess.TimeoutExpired:
            problem = problem or "%s took too long to start." % exe.stem
            continue
        except OSError:
            problem = problem or _explain_launch_failure(exe)
            continue
        if r.returncode != 0:
            problem = problem or "%s did not start correctly. Try downloading the tools again." % exe.stem
        elif exe == YTDLP:
            version = r.stdout.decode("utf-8", "replace").strip()
    return version, problem


def refresh_tool_state(**extra) -> None:
    p = tools_present()
    version, problem = probe_tools()
    ok = not problem
    HUB.update("tools", ytdlp=p["ytdlp"] and ok, ffmpeg=p["ffmpeg"] and ok,
               ytdlp_version=version, error=problem, **extra)


_tools_lock = threading.Lock()


def install_tools(only_ytdlp: bool = False) -> None:
    """Download whatever is missing (or just refresh yt-dlp). Runs in a thread."""
    if not _tools_lock.acquire(blocking=False):
        return
    try:
        BIN_DIR.mkdir(parents=True, exist_ok=True)
        TMP_DIR.mkdir(parents=True, exist_ok=True)
        plan = tool_plan()
        have = tools_present()
        want_yt = only_ytdlp or not have["ytdlp"]
        want_ff = (not only_ytdlp) and not have["ffmpeg"]
        units = (1 if want_yt else 0) + (len(plan["ffmpeg"][0]) if want_ff else 0)
        HUB.update("tools", busy=True, error="", percent=0, message="Starting")

        def report(label, index, got, total):
            frac = (got / total) if total else 0.0
            mb = got / 1048576
            msg = "Downloading %s (%.0f MB)" % (label, mb)
            if total:
                msg = "Downloading %s (%.0f of %.0f MB)" % (label, mb, total / 1048576)
            HUB.update("tools", percent=int(((index + frac) / max(units, 1)) * 100), message=msg)

        done = 0
        if want_yt:
            tmp = TMP_DIR / "yt-dlp.part"
            http_download(plan["ytdlp"], tmp, lambda g, t: report("yt-dlp", 0, g, t))
            _make_exec(tmp)
            os.replace(tmp, YTDLP)
            done = 1
        if want_ff:
            failure = None
            for sources in plan["ffmpeg"]:
                try:
                    for n, (kind, url) in enumerate(sources):
                        tmp = TMP_DIR / ("ffmpeg_%d.part" % n)
                        http_download(url, tmp, lambda g, t, n=n: report("ffmpeg", done + n, g, t))
                        HUB.update("tools", message="Unpacking ffmpeg")
                        _extract_ffmpeg(kind, tmp)
                        tmp.unlink(missing_ok=True)
                    failure = None
                    break
                except (urllib.error.URLError, OSError, UserError, zipfile.BadZipFile, tarfile.TarError) as e:
                    failure = e
            if failure:
                raise failure
        HUB.update("tools", message="Checking installation")
        refresh_tool_state(busy=False, percent=100, message="Ready")
    except urllib.error.HTTPError as e:
        HUB.update("tools", busy=False, error="The download server answered with an error (%s). Try again in a moment." % e.code)
    except (urllib.error.URLError, socket.timeout, ConnectionError) as e:
        reason = str(getattr(e, "reason", e))
        text = friendly(reason, "Could not download the tools. Check your internet connection and try again.")
        HUB.update("tools", busy=False, error=text)
    except UserError as e:
        HUB.update("tools", busy=False, error=str(e))
    except PermissionError:
        HUB.update("tools", busy=False, error="Could not write to the files/bin folder. Is the drive read-only or full?")
    except Exception:
        log_error(traceback.format_exc())
        HUB.update("tools", busy=False, error="Something went wrong while installing the tools.")
    finally:
        _tools_lock.release()


# --------------------------------------------------------------------------
# Channel inspection
# --------------------------------------------------------------------------

CHANNEL_RE = re.compile(
    r"^(?:https?://)?(?:www\.|m\.)?youtube\.com/"
    r"(@[^/?#\s]+|channel/UC[\w-]{22}|c/[^/?#\s]+|user/[^/?#\s]+)"
    r"(?:/[a-z]+)?/?(?:[?#].*)?$", re.I)

INSPECT_CACHE: dict = {}
COUNT_CACHE: dict = {}


def parse_channel_url(raw: str) -> str:
    """Normalise any supported channel link to https://www.youtube.com/<path>."""
    raw = (raw or "").strip()
    if not raw:
        raise UserError("Paste a channel link first.")
    if re.fullmatch(r"@[\w.\-]+", raw):
        raw = "https://www.youtube.com/" + raw
    elif re.fullmatch(r"UC[\w-]{22}", raw):
        raw = "https://www.youtube.com/channel/" + raw
    low = raw.lower()
    if "watch?v=" in low or "youtu.be/" in low or "/shorts/" in low or "/playlist" in low or "/live/" in low:
        raise UserError("That looks like a video or playlist link. Paste a channel link instead, "
                        "such as youtube.com/@name or youtube.com/channel/UC...")
    m = CHANNEL_RE.match(raw)
    if not m:
        raise UserError("That does not look like a YouTube channel link. Supported formats are "
                        "youtube.com/@handle, youtube.com/channel/ID and youtube.com/c/Name.")
    return "https://www.youtube.com/" + m.group(1)


_JS_RUNTIME_ARGS = None


def js_runtime_args() -> list:
    """Enable a supported system JS runtime for YouTube's signature solver."""
    global _JS_RUNTIME_ARGS
    if _JS_RUNTIME_ARGS is not None:
        return list(_JS_RUNTIME_ARGS)
    for runtime, minimum in (("node", (22, 0)), ("deno", (2, 3))):
        path = shutil.which(runtime)
        if not path:
            continue
        try:
            result = subprocess.run([path, "--version"], capture_output=True, text=True,
                                    timeout=5, creationflags=NOWIN, check=False)
            match = re.search(r"(?:v|deno\s+)?(\d+)\.(\d+)", result.stdout + result.stderr, re.I)
            if result.returncode == 0 and match and tuple(map(int, match.groups())) >= minimum:
                _JS_RUNTIME_ARGS = ["--js-runtimes", runtime + ":" + path]
                return list(_JS_RUNTIME_ARGS)
        except (OSError, subprocess.TimeoutExpired):
            continue
    _JS_RUNTIME_ARGS = []
    return []


def ytdlp_base(settings=None) -> list:
    args = [str(YTDLP), "--ignore-config", "--cache-dir", str(CACHE_DIR), "--encoding", "utf-8"]
    args += js_runtime_args()
    browser = (settings or load_settings()).get("youtube_browser")
    if browser:
        args += ["--cookies-from-browser", browser]
    return args


def require_tools() -> None:
    p = tools_present()
    if not (p["ytdlp"] and p["ffmpeg"]):
        raise UserError("The required tools are not installed yet. Use Set up tools first.")
    if not js_runtime_args():
        raise UserError("Full YouTube support needs Deno 2.3+ or Node.js 22+. Install either runtime and restart Mnemosyne.")


def _pick_thumb(thumbs, key: str):
    thumbs = thumbs or []
    for t in thumbs:
        if t.get("id") == key and t.get("url"):
            return t["url"]
    word = key.split("_")[0]
    cands = [t for t in thumbs if word in str(t.get("id", "")) and t.get("url")]
    if cands:
        cands.sort(key=lambda t: (t.get("width") or 0) * (t.get("height") or 0))
        return cands[-1]["url"]
    return None


def safe_folder_name(name: str, fallback: str) -> str:
    name = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", name or "").strip(" .")
    name = re.sub(r"\s+", " ", name)[:80].strip(" .")
    return name or fallback


def youtube_api_channel(base: str, api_key: str):
    """Fetch public channel details from the YouTube Data API when addressable."""
    path = urllib.parse.urlsplit(base).path.strip("/")
    if path.startswith("channel/"):
        params = {"id": path.split("/", 1)[1]}
    elif path.startswith("@"):
        params = {"forHandle": path[1:]}
    else:
        return None
    params.update({"part": "snippet,statistics,brandingSettings", "key": api_key})
    url = "https://www.googleapis.com/youtube/v3/channels?" + urllib.parse.urlencode(params)
    try:
        with urllib.request.urlopen(url, timeout=20) as response:
            payload = json.loads(response.read().decode("utf-8", "replace"))
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", "replace")
        log_error("YouTube Data API error: " + detail[-1000:])
        raise UserError("The YouTube Data API request failed. Check the API key and its quota.")
    except (urllib.error.URLError, TimeoutError, ValueError) as exc:
        log_error("YouTube Data API error: " + str(exc))
        raise UserError("Could not reach the YouTube Data API. Check your connection and try again.")
    items = payload.get("items") or []
    if not items:
        return None
    item = items[0]
    snippet = item.get("snippet") or {}
    thumbs = snippet.get("thumbnails") or {}
    avatar = next((thumbs[k].get("url") for k in ("high", "medium", "default") if thumbs.get(k, {}).get("url")), None)
    branding = item.get("brandingSettings") or {}
    image = branding.get("image") or {}
    stats = item.get("statistics") or {}
    return {"id": item.get("id", ""), "name": snippet.get("title", ""),
            "handle": snippet.get("customUrl", ""), "avatar": avatar,
            "banner": image.get("bannerExternalUrl"),
            "count": int(stats["videoCount"]) if str(stats.get("videoCount", "")).isdigit() else None}


def inspect_channel(raw: str, settings=None) -> dict:
    base = parse_channel_url(raw)
    if base in INSPECT_CACHE:
        return INSPECT_CACHE[base]
    require_tools()
    try:
        r = subprocess.run(
            ytdlp_base(settings) + ["--no-warnings", "-J", "--flat-playlist", "--playlist-items", "1", base + "/videos"],
            capture_output=True, timeout=120, env=child_env(), creationflags=NOWIN)
    except subprocess.TimeoutExpired:
        raise UserError("YouTube took too long to answer. Try again in a moment.")
    err = r.stderr.decode("utf-8", "replace")
    if r.returncode != 0 or not r.stdout.strip():
        if "videos tab" in err.lower():
            raise UserError("This channel has no public Videos tab.")
        log_error("inspect failed: " + err[-800:])
        raise UserError(friendly(err, "That channel could not be read. Check the link and try again."))
    try:
        info = json.loads(r.stdout.decode("utf-8", "replace"))
    except ValueError:
        raise UserError("YouTube sent back something unexpected. Try again in a moment.")
    name = info.get("channel") or info.get("uploader") or re.sub(r"\s*-\s*Videos$", "", info.get("title") or "")
    cid = info.get("channel_id") or info.get("id") or ""
    count = info.get("playlist_count")
    result = {
        "url": base,
        "name": name or cid or "Channel",
        "handle": info.get("uploader_id") or "",
        "id": cid,
        "avatar": _pick_thumb(info.get("thumbnails"), "avatar_uncropped"),
        "banner": _pick_thumb(info.get("thumbnails"), "banner_uncropped"),
        "count": count if isinstance(count, int) and count > 1 else COUNT_CACHE.get(base),
        "folder": safe_folder_name(name, cid or "Channel"),
    }
    api_key = (settings or load_settings()).get("youtube_api_key", "")
    if api_key:
        api_info = youtube_api_channel(base, api_key)
        if api_info:
            for field in ("id", "name", "handle", "avatar", "banner", "count"):
                if api_info.get(field) is not None and api_info.get(field) != "":
                    result[field] = api_info[field]
            result["folder"] = safe_folder_name(result["name"], result["id"] or "Channel")
    INSPECT_CACHE[base] = result
    return result


def inspect_video(raw: str, settings=None) -> dict:
    """Inspect one direct video URL from any site supported by yt-dlp."""
    url = (raw or "").strip()
    parsed = urllib.parse.urlsplit(url)
    if parsed.scheme not in ("http", "https") or not parsed.netloc or len(url) > 2000:
        raise UserError("Paste a direct http or https video link from a yt-dlp-supported site.")
    require_tools()
    try:
        result = subprocess.run(
            ytdlp_base(settings) + ["--no-warnings", "--no-playlist", "--skip-download", "-J", url],
            capture_output=True, timeout=120, env=child_env(), creationflags=NOWIN)
    except subprocess.TimeoutExpired:
        raise UserError("The video site took too long to answer. Try again in a moment.")
    err = result.stderr.decode("utf-8", "replace")
    if result.returncode != 0 or not result.stdout.strip():
        log_error("video inspection failed: " + err[-1000:])
        raise UserError(friendly(err, "That video link could not be read. Check the URL and try again."))
    try:
        info = json.loads(result.stdout.decode("utf-8", "replace"))
    except ValueError:
        raise UserError("The video site returned unexpected information. Try again.")
    thumbs = info.get("thumbnails") or []
    thumbnail = info.get("thumbnail")
    if thumbs:
        best = max(thumbs, key=lambda t: (t.get("width") or 0) * (t.get("height") or 0))
        thumbnail = best.get("url") or thumbnail
    title = info.get("title") or info.get("id") or "Video"
    return {"kind": "video", "url": info.get("webpage_url") or url,
            "id": info.get("id") or "", "name": title, "title": title,
            "handle": info.get("uploader") or info.get("channel") or "",
            "thumbnail": thumbnail,
            "duration": info.get("duration") if isinstance(info.get("duration"), (int, float)) else None,
            "folder": "Videos"}


def count_videos(raw: str, settings=None) -> int:
    base = parse_channel_url(raw)
    if base in COUNT_CACHE:
        return COUNT_CACHE[base]
    require_tools()
    try:
        r = subprocess.run(ytdlp_base(settings) + ["--no-warnings", "--flat-playlist", "--print", "id", base + "/videos"],
                           capture_output=True, timeout=900, env=child_env(), creationflags=NOWIN)
    except subprocess.TimeoutExpired:
        raise UserError("Counting the videos took too long.")
    ids = [x for x in r.stdout.decode("utf-8", "replace").split() if x]
    COUNT_CACHE[base] = len(ids)
    if base in INSPECT_CACHE:
        INSPECT_CACHE[base]["count"] = len(ids)
    return len(ids)


def fetch_image(url: str, dest: Path) -> None:
    """Download an image and store it as a real JPEG via ffmpeg."""
    if not url or dest.exists():
        return
    TMP_DIR.mkdir(parents=True, exist_ok=True)
    raw = TMP_DIR / "image.bin"
    http_download(url, raw, lambda *_: None)
    r = subprocess.run([str(FFMPEG), "-y", "-loglevel", "error", "-i", str(raw), "-q:v", "2", str(dest)],
                       capture_output=True, env=child_env(), creationflags=NOWIN)
    if r.returncode != 0 or not dest.exists():
        shutil.copyfile(raw, dest)
    raw.unlink(missing_ok=True)


# --------------------------------------------------------------------------
# Download job
# --------------------------------------------------------------------------

P_ITEM = re.compile(r"\[download\] Downloading item (\d+) of (\d+)")
P_ERR = re.compile(r"^ERROR: (?:\[[^\]]+\] )?([\w-]{11}): (.*)$")

_ENCODER_PROBES = {}
_ENCODER_PROBE_LOCK = threading.Lock()


def _encoder_works(name: str) -> bool:
    """Check that the bundled ffmpeg can actually encode with this encoder."""
    with _ENCODER_PROBE_LOCK:
        if name in _ENCODER_PROBES:
            return _ENCODER_PROBES[name]
    try:
        result = subprocess.run(
            [str(FFMPEG), "-hide_banner", "-loglevel", "error", "-f", "lavfi",
             "-i", "color=c=black:s=320x240:r=1", "-frames:v", "1", "-c:v", name,
             "-f", "null", "-"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            timeout=8, creationflags=NOWIN, check=False)
        works = result.returncode == 0
    except (OSError, subprocess.TimeoutExpired):
        works = False
    with _ENCODER_PROBE_LOCK:
        _ENCODER_PROBES[name] = works
    return works


def _auto_encoder(family: str, preference: str) -> str:
    """Choose a tested encoder, honoring a hardware preference when possible."""
    variants = {
        "h264": {"cpu": ["libx264"], "nvidia": ["h264_nvenc"],
                 "amd": ["h264_amf"], "intel": ["h264_qsv"]},
        "hevc": {"cpu": ["libx265"], "nvidia": ["hevc_nvenc"],
                 "amd": ["hevc_amf"], "intel": ["hevc_qsv"]},
        "av1": {"cpu": ["libsvtav1", "libaom-av1"], "nvidia": ["av1_nvenc"],
                "amd": ["av1_amf"], "intel": ["av1_qsv"]},
        "vp9": {"cpu": ["libvpx-vp9"], "nvidia": [], "amd": [], "intel": []},
    }
    by_vendor = variants[family]
    if preference == "auto":
        order = ["nvidia", "amd", "intel", "cpu"]
    elif preference == "cpu":
        order = ["cpu"]
    else:
        order = [preference] + [v for v in ("nvidia", "amd", "intel", "cpu") if v != preference]
    for vendor in order:
        for encoder in by_vendor[vendor]:
            if _encoder_works(encoder):
                return encoder
    raise UserError("No working %s encoder was found in the bundled FFmpeg. Choose another codec or hardware preference." % family.upper())


def _num(s):
    try:
        v = float(s)
        return v if v == v else None
    except (TypeError, ValueError):
        return None


def build_args(s: dict, outdir: Path) -> list:
    """Build yt-dlp arguments from the user's download and sidecar settings."""
    output_template = (FILENAMES[s["filename"]] + "/" + FILENAMES[s["filename"]]
                       if s.get("video_subfolders", True) else FILENAMES[s["filename"]])
    a = ["--ignore-config", "--cache-dir", str(CACHE_DIR), "--ffmpeg-location", str(BIN_DIR),
         "--encoding", "utf-8", "--newline", "--no-colors", "--ignore-errors",
         "--windows-filenames", "--trim-filenames", "150",
         "--retries", "10", "--fragment-retries", "10", "--concurrent-fragments", "4",
         "--sleep-requests", "1" if s["slow_pacing"] else "0",
         "--sleep-interval", "5" if s["slow_pacing"] else "1",
         "--max-sleep-interval", "10" if s["slow_pacing"] else "3",
         "-P", str(outdir), "-o", output_template + ".%(ext)s",
         "--download-archive", str(outdir / "archive.txt")]
    if s.get("embed_thumbnail", True):
        a += ["--embed-thumbnail"]
    else:
        a += ["--write-thumbnail", "--convert-thumbnails", s["thumb_format"]]
    if s["download_mode"] == "video":
        a += ["--no-playlist"]
    a += js_runtime_args()
    if s.get("youtube_browser"):
        a += ["--cookies-from-browser", s["youtube_browser"]]
    a += ["--progress-template",
          "download:[[P]]%(progress.status)s|%(progress.downloaded_bytes)s|%(progress.total_bytes)s|"
          "%(progress.total_bytes_estimate)s|%(progress.speed)s|%(progress.eta)s|%(progress.filename)s|"
          "%(info.id)s|%(info.format_id)s|%(info.title)s",
          "--progress-template",
          "postprocess:[[PP]]%(progress.status)s|%(progress.postprocessor)s|%(info.id)s"]
    q = s["quality"]
    if q == "audio":
        a += ["-f", "bestaudio/best", "-x", "--audio-format", s["audio_format"],
              "--audio-quality", "0" if s["audio_quality"] == "best" else s["audio_quality"] + "K"]
    else:
        h = QUALITIES[q]
        sort = []
        if h:
            a += ["-f", "bv*[height<=%d]+ba/b[height<=%d]/bv*+ba/b" % (h, h)]
            sort.append("res:%d" % h)
        else:
            a += ["-f", "bv*+ba/b"]
            sort.append("res")
        if s["audio_quality"] != "best":
            sort.append("abr:" + s["audio_quality"])
        c = s["container"]
        if c in ("mp4", "mov"):
            sort += ["vext:mp4", "aext:m4a"]
        elif c == "webm":
            sort += ["vext:webm", "aext:webm"]
        a += ["-S", ",".join(sort), "--merge-output-format", c]
        ffmpeg_args = []
        codec = s["video_codec"]
        auto_family = codec.removeprefix("auto_") if codec.startswith("auto_") else None
        if auto_family:
            codec = _auto_encoder(auto_family, s["hardware_preference"])
        elif not codec and s["max_height"]:
            # Filtering requires encoding; use an encoder that works here.
            codec = _auto_encoder("vp9" if c == "webm" else "h264", s["hardware_preference"])
        if codec:
            ffmpeg_args += ["-c:v", codec]
        if s["audio_codec"]:
            ffmpeg_args += ["-c:a", s["audio_codec"]]
        if s["max_height"]:
            # Bound the output to the source width and requested height. This
            # avoids FFmpeg filtergraph comma escaping and never upscales small videos.
            ffmpeg_args += ["-vf", "scale=iw:%s:force_original_aspect_ratio=decrease:force_divisible_by=2"
                            % s["max_height"]]
        if ffmpeg_args:
            a += ["--postprocessor-args", "Merger+ffmpeg_o:" + " ".join(ffmpeg_args)]
    ex = s["extras"]
    if ex["metadata"]:
        a += ["--write-description", "--write-info-json"]
    if s["embed_subs"] and q != "audio":
        a += ["--write-subs", "--write-auto-subs", "--sub-langs", "en", "--embed-subs"]
        if not ex["subs"]:
            a += ["--compat-options", "no-keep-subs"]
    if ex["subs"]:
        a += ["--write-subs", "--write-auto-subs", "--sub-langs", "en", "--convert-subs", "srt"]
    if ex["keep_video"]:
        a += ["--keep-video"]
    return a


class JobManager:
    def __init__(self):
        self.lock = threading.RLock()
        self.proc = None
        self.stop = None
        self.status = "idle"
        self.settings = None
        self.info = None
        self.outdir = None
        self.urls = []
        self.failures = {}
        self.counts = {"done": 0, "skipped": 0, "failed": 0}
        self.finished_ids = set()
        self.titles = {}
        self.last_errors = []
        self.last_push = 0.0
        self._reset_run()

    # -- state helpers -----------------------------------------------------
    def _reset_run(self):
        self.pl = {"x": 0, "n": 0, "offset": 0}
        self.streams = {}
        self.cur = None
        self.expected_total = 0

    def active(self) -> bool:
        return self.status in ("preparing", "running", "paused", "stopping")

    def _set(self, **kw):
        if "status" in kw:
            self.status = kw["status"]
        HUB.update("job", **kw)

    def _push(self, force=False):
        now = time.time()
        if not force and now - self.last_push < 0.2:
            return
        self.last_push = now
        pl = self.pl
        if pl["n"]:
            overall = {"index": pl["offset"] + pl["x"], "total": pl["offset"] + pl["n"]}
        else:
            seen = self.counts["done"] + self.counts["skipped"] + self.counts["failed"]
            total = self.expected_total
            overall = {"index": min(seen + 1, total) if total else 0, "total": total}
        self.counts["failed"] = len(self.failures)
        HUB.update("job", overall=overall, counts=dict(self.counts), current=self.cur,
                   failures=list(self.failures.values()))

    # -- control -----------------------------------------------------------
    def start(self, url: str, settings: dict):
        with self.lock:
            if self.active():
                raise UserError("A download is already in progress.")
            require_tools()
            self.status = "preparing"
        try:
            info = (inspect_video(url, settings) if settings["download_mode"] == "video"
                    else inspect_channel(url, settings))
        except Exception:
            self.status = "idle"
            raise
        with self.lock:
            self.settings = settings
            self.info = info
            is_video = settings["download_mode"] == "video"
            self.outdir = DOWNLOADS_DIR / ("Videos" if is_video else info["folder"])
            base = info["url"]
            self.urls = [base] if is_video else [base + "/videos"]
            if not is_video and settings["extras"]["shorts"]:
                self.urls.append(base + "/shorts")
            if not is_video and settings["extras"]["live"]:
                self.urls.append(base + "/streams")
            self.failures = {}
            self.counts = {"done": 0, "skipped": 0, "failed": 0}
            self.finished_ids = set()
            self.last_errors = []
            self._reset_run()
            self.expected_total = 1 if is_video else info.get("count") or 0
            self._set(status="preparing", message="Preparing", folder=str(self.outdir),
                      channel={"name": info["name"], "url": base,
                               "avatar": info.get("avatar") or info.get("thumbnail"),
                               "kind": info.get("kind", "channel")},
                      current=None, failures=[], counts=dict(self.counts),
                      overall={"index": 0, "total": self.expected_total})
        threading.Thread(target=self._prepare_then_run, daemon=True).start()

    def _prepare_then_run(self):
        try:
            self.outdir.mkdir(parents=True, exist_ok=True)
            if (self.settings["download_mode"] == "channel" and
                    self.settings["extras"].get("channel_art")):
                (self.outdir / "channel.json").write_text(
                    json.dumps({"name": self.info["name"], "url": self.info["url"], "id": self.info["id"]}, indent=2),
                    encoding="utf-8")
                for key, fname in (("avatar", "avatar.jpg"), ("banner", "banner.jpg")):
                    try:
                        fetch_image(self.info.get(key), self.outdir / fname)
                    except Exception:
                        log_error("could not fetch %s: %s" % (key, traceback.format_exc()))
        except OSError:
            self._set(status="error", message="Could not create the download folder. Is the drive full or read-only?")
            return
        if self.stop == "cancel":
            return
        self._launch(self.urls)

    def pause(self):
        with self.lock:
            if self.status != "running":
                raise UserError("Nothing is downloading right now.")
            self.stop = "pause"
            self._set(status="stopping", message="Pausing")
            self._kill()

    def resume(self):
        with self.lock:
            if self.status != "paused":
                raise UserError("There is nothing to resume.")
            self.counts["skipped"] = 0
            self._reset_run()
            self.expected_total = 1 if self.settings and self.settings.get("download_mode") == "video" else (self.info or {}).get("count") or 0
            threading.Thread(target=self._launch, args=(self.urls,), daemon=True).start()

    def cancel(self):
        with self.lock:
            if self.status == "paused":
                self._set(status="cancelled", message="Cancelled. Partial files were kept, so you can start again later.")
                return
            if self.status not in ("running", "preparing", "stopping"):
                raise UserError("Nothing is running.")
            self.stop = "cancel"
            self._set(status="stopping", message="Cancelling")
            self._kill()

    def retry(self):
        with self.lock:
            if self.status not in ("done", "cancelled", "error") or not self.failures:
                raise UserError("There are no failed videos to retry.")
            ids = list(self.failures)
            self.urls = [self.failures[i].get("url") or "https://www.youtube.com/watch?v=" + i for i in ids]
            self.failures = {}
            self.counts["failed"] = 0
            self.counts["skipped"] = 0
            self._reset_run()
            self.expected_total = len(ids)
            threading.Thread(target=self._launch, args=(self.urls,), daemon=True).start()

    def shutdown(self):
        self.stop = "cancel"
        self._kill()

    def _kill(self):
        p = self.proc
        if not p or p.poll() is not None:
            return
        try:
            if IS_WIN:
                subprocess.run(["taskkill", "/PID", str(p.pid), "/T", "/F"], capture_output=True, creationflags=NOWIN)
            else:
                os.killpg(os.getpgid(p.pid), signal.SIGTERM)
        except Exception:
            try:
                p.kill()
            except Exception:
                pass

    # -- the run itself ----------------------------------------------------
    def _launch(self, urls):
        self.stop = None
        self._set(status="running", message="")
        try:
            cmd = [str(YTDLP)] + build_args(self.settings, self.outdir) + list(urls)
        except UserError as e:
            self._set(status="error", message=str(e))
            return
        LOG_DIR.mkdir(parents=True, exist_ok=True)
        try:
            logf = open(LOG_DIR / "last-run.log", "a", encoding="utf-8")
            logf.write("\n==== %s ====\n" % time.strftime("%Y-%m-%d %H:%M:%S"))
        except OSError:
            logf = None
        try:
            self.proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                         env=child_env(), creationflags=NOWIN,
                                         start_new_session=not IS_WIN)
        except OSError:
            self._set(status="error", message="yt-dlp could not be started. Try Update yt-dlp or reinstall the tools.")
            return
        try:
            for raw in iter(self.proc.stdout.readline, b""):
                line = raw.decode("utf-8", "replace").rstrip()
                if logf:
                    logf.write(line + "\n")
                try:
                    self._handle_line(line)
                except Exception:
                    log_error(traceback.format_exc())
            rc = self.proc.wait()
        finally:
            if logf:
                logf.close()
        self._finish(rc)

    def _handle_line(self, line: str):
        if line.startswith("[[P]]"):
            f = (line[5:].split("|", 9) + [""] * 10)[:10]
            status, down, tot, est, speed, eta, fname, vid, fmt, title = f
            total = _num(tot) or _num(est)
            frac = 1.0 if status == "finished" else ((_num(down) or 0) / total if total else 0.0)
            seen = self.streams.setdefault(vid, [])
            if fname not in seen:
                seen.append(fname)
            expected = 2 if "+" in fmt else 1
            idx = min(len(seen) - 1, expected - 1)
            pct = max(0.0, min(100.0, (idx + min(frac, 1.0)) / expected * 100))
            if title and title != "NA":
                self.titles[vid] = title
            self.cur = {"id": vid, "title": self.titles.get(vid, vid), "percent": round(pct, 1),
                        "speed": _num(speed), "eta": _num(eta), "phase": "Downloading"}
            self._push()
        elif line.startswith("[[PP]]"):
            status, pp, vid = (line[6:].split("|", 2) + ["", "", ""])[:3]
            if pp == "MoveFiles" and status == "finished":
                if vid not in self.finished_ids:
                    self.finished_ids.add(vid)
                    if vid not in self.failures:
                        self.counts["done"] += 1
                if self.cur and self.cur.get("id") == vid:
                    self.cur.update(speed=None, eta=None,
                                    phase="Failed" if vid in self.failures else "Saved")
                    if vid not in self.failures:
                        self.cur["percent"] = 100.0
                self._push(True)
            elif status == "started" and self.cur:
                phase = ("Merging streams" if "Merger" in pp else
                         "Converting audio" if "Audio" in pp else
                         "Processing thumbnail" if "Thumbnail" in pp else
                         "Processing subtitles" if "Subtitle" in pp else "Finishing")
                self.cur.update(phase=phase, speed=None, eta=None)
                self._push(True)
        else:
            m = P_ITEM.search(line)
            if m:
                x, n = int(m.group(1)), int(m.group(2))
                pl = self.pl
                if pl["n"] and (n != pl["n"] or x < pl["x"]):
                    pl["offset"] += pl["n"]
                pl["x"], pl["n"] = x, n
                self.cur = {"id": "", "title": "Looking up video", "percent": 0, "speed": None,
                            "eta": None, "phase": "Starting"}
                self.streams = {}
                self._push(True)
            elif "has already been recorded in the archive" in line:
                self.counts["skipped"] += 1
                self._push()
            elif line.startswith("ERROR:"):
                m = P_ERR.match(line)
                if m:
                    vid, msg = m.group(1), m.group(2)
                    if vid not in self.finished_ids:
                        if self.settings and self.settings.get("download_mode") == "video":
                            failed_url = self.info.get("url", "") if self.info else ""
                        else:
                            failed_url = "https://www.youtube.com/watch?v=" + vid
                        self.failures[vid] = {
                            "id": vid, "title": self.titles.get(vid, ""),
                            "reason": friendly(msg, "This video could not be downloaded."),
                            "url": failed_url}
                        self._push(True)
                    if "not a bot" in msg.lower() or "too many requests" in msg.lower() or "429" in msg:
                        # The block applies to the session, so continuing through
                        # a large channel only creates thousands of identical failures.
                        self.stop = "rate_limit"
                        self._kill()
                else:
                    self.last_errors.append(line)
                    self.last_errors = self.last_errors[-5:]
                    vid = (self.cur or {}).get("id")
                    if vid and vid not in self.finished_ids:
                        failed_url = (self.info.get("url", "") if self.settings and
                                      self.settings.get("download_mode") == "video" else
                                      "https://www.youtube.com/watch?v=" + vid)
                        reason = line.removeprefix("ERROR: ").strip()
                        self.failures[vid] = {
                            "id": vid, "title": (self.cur or {}).get("title", vid),
                            "reason": friendly(reason, "Video post-processing failed."),
                            "url": failed_url}
                        self._push(True)

    def _finish(self, rc: int):
        self._push(True)
        c = self.counts
        if self.stop == "pause":
            self._set(status="paused", message="Paused. Resume to continue where it left off.")
        elif self.stop == "cancel":
            self._set(status="cancelled", message="Cancelled. Partial files were kept, so you can start again later.")
        elif self.stop == "rate_limit":
            message = ("The video site blocked requests. The run stopped early; wait before retrying and enable Slower request pacing."
                       if self.settings and self.settings.get("download_mode") == "video" else
                       "YouTube blocked requests with a bot check. The run stopped early. Wait before retrying and enable Slower request pacing.")
            self._set(status="done", message=message, current=None)
        elif rc not in (0, 1) or (rc != 0 and c["done"] + c["skipped"] + len(self.failures) == 0):
            text = friendly(" ".join(self.last_errors), "The download stopped unexpectedly. Details are in files/data/logs/last-run.log.")
            self._set(status="error", message=text, current=None)
        else:
            msg = "Finished. %d downloaded, %d already saved, %d failed." % (c["done"], c["skipped"], len(self.failures))
            if rc != 0 and not self.failures and self.last_errors:
                msg += " Some items could not be read; see files/data/logs/last-run.log."
            self._set(status="done", message=msg, current=None)
        self.stop = None


JOBS = JobManager()


# --------------------------------------------------------------------------
# HTTP server
# --------------------------------------------------------------------------

CSP = ("default-src 'self'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; "
       "img-src https: data:; connect-src 'self'; base-uri 'none'; form-action 'none'")


def open_folder(path: Path) -> None:
    """Show a folder in the system file manager (Explorer, Finder, or the Linux default)."""
    path.mkdir(parents=True, exist_ok=True)
    try:
        if IS_WIN:
            os.startfile(str(path))  # noqa: S606
        elif sys.platform == "darwin":
            subprocess.run(["open", str(path)], check=True)
        else:
            opener = shutil.which("xdg-open") or shutil.which("gio")
            if not opener:
                raise OSError("no file manager launcher")
            cmd = [opener, "open", str(path)] if opener.endswith("gio") else [opener, str(path)]
            subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except (OSError, subprocess.CalledProcessError):
        raise UserError("Could not open the folder automatically. It is here: %s" % path)


class Handler(BaseHTTPRequestHandler):
    server_version = "Mnemosyne"

    def log_message(self, *args):
        pass

    # -- plumbing ----------------------------------------------------------
    def _send(self, code: int, body: bytes, ctype: str, extra=None):
        try:
            self.send_response(code)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Referrer-Policy", "no-referrer")
            self.send_header("Content-Security-Policy", CSP)
            for k, v in (extra or {}).items():
                self.send_header(k, v)
            self.end_headers()
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
            # Browsers can close a request while navigating, refreshing, or
            # cancelling fetch(). A disconnected client cannot receive errors.
            return

    def _json(self, obj, code=200):
        self._send(code, json.dumps(obj).encode("utf-8"), "application/json; charset=utf-8")

    def _host_ok(self) -> bool:
        return self.headers.get("Host", "") in self.server.allowed_hosts

    def _origin_ok(self) -> bool:
        origin = self.headers.get("Origin")
        return origin is None or origin in self.server.allowed_origins

    # -- routes ------------------------------------------------------------
    def do_GET(self):
        if not self._host_ok():
            return self._send(403, b"Forbidden", "text/plain")
        path = self.path.split("?", 1)[0]
        if path in ("/", "/index.html"):
            try:
                page = INDEX_FILE.read_bytes()
                theme = HUB.state["settings"].get("theme")
                if theme in ("light", "dark"):
                    page = page.replace(b'<html lang="en">', b'<html lang="en" data-theme="%s">' % theme.encode(), 1)
                self._send(200, page, "text/html; charset=utf-8")
            except OSError:
                self._send(500, b"index.html is missing from the app folder.", "text/plain")
        elif path == "/api/state":
            self._send(200, HUB.snapshot()[0].encode("utf-8"), "application/json; charset=utf-8")
        elif path == "/api/events":
            self._events()
        else:
            self._send(404, b"Not found", "text/plain")

    def _events(self):
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Connection", "close")
        self.end_headers()
        last = -1
        try:
            while True:
                data, ver = HUB.snapshot()
                if ver != last:
                    self.wfile.write(("data: " + data + "\n\n").encode("utf-8"))
                    last = ver
                else:
                    self.wfile.write(b": ping\n\n")
                self.wfile.flush()
                HUB.wait(last, 15)
        except (BrokenPipeError, ConnectionResetError, OSError):
            return

    def do_POST(self):
        if not (self._host_ok() and self._origin_ok()):
            return self._json({"ok": False, "error": "Request blocked."}, 403)
        try:
            n = int(self.headers.get("Content-Length") or 0)
            body = json.loads(self.rfile.read(min(n, 65536)) or b"{}")
            if not isinstance(body, dict):
                body = {}
        except ValueError:
            return self._json({"ok": False, "error": "Bad request."}, 400)
        path = self.path.split("?", 1)[0]
        try:
            self._json(self._route(path, body))
        except UserError as e:
            self._json({"ok": False, "error": str(e)})
        except Exception:
            log_error(traceback.format_exc())
            self._json({"ok": False, "error": "Something went wrong. Details were saved to files/data/logs/errors.log."})

    def _route(self, path: str, body: dict) -> dict:
        if path == "/api/setup":
            if not HUB.state["tools"]["busy"]:
                threading.Thread(target=install_tools, daemon=True).start()
            return {"ok": True}
        if path == "/api/update-ytdlp":
            if JOBS.active():
                raise UserError("Finish or cancel the current download before updating.")
            if not HUB.state["tools"]["busy"]:
                threading.Thread(target=install_tools, kwargs={"only_ytdlp": True}, daemon=True).start()
            return {"ok": True}
        if path == "/api/inspect":
            settings = clean_settings(body.get("settings")) if isinstance(body.get("settings"), dict) else load_settings()
            mode = body.get("mode", settings["download_mode"])
            source = inspect_video(body.get("url", ""), settings) if mode == "video" else inspect_channel(body.get("url", ""), settings)
            return {"ok": True, "source": source}
        if path == "/api/count":
            return {"ok": True, "count": count_videos(body.get("url", ""), load_settings())}
        if path == "/api/settings":
            s = clean_settings(body)
            save_settings(s)
            INSPECT_CACHE.clear()
            COUNT_CACHE.clear()
            HUB.update("settings", **s)
            return {"ok": True}
        if path == "/api/start":
            s = clean_settings(body.get("settings"))
            s["url"] = body.get("url", s["url"])
            save_settings(s)
            INSPECT_CACHE.clear()
            COUNT_CACHE.clear()
            HUB.update("settings", **s)
            JOBS.start(body.get("url", ""), s)
            return {"ok": True}
        if path == "/api/pause":
            JOBS.pause()
            return {"ok": True}
        if path == "/api/resume":
            JOBS.resume()
            return {"ok": True}
        if path == "/api/cancel":
            JOBS.cancel()
            return {"ok": True}
        if path == "/api/retry":
            JOBS.retry()
            return {"ok": True}
        if path == "/api/open-folder":
            folder = HUB.state["job"].get("folder") or str(DOWNLOADS_DIR)
            target = Path(folder).resolve()
            if DOWNLOADS_DIR.resolve() not in (target, *target.parents):
                target = DOWNLOADS_DIR
            open_folder(target)
            return {"ok": True}
        if path == "/api/quit":
            if JOBS.active() and not body.get("force"):
                raise UserError("A download is in progress. Cancel it first, or quit anyway.")
            JOBS.shutdown()
            threading.Thread(target=self.server.shutdown, daemon=True).start()
            return {"ok": True}
        raise UserError("Unknown request.")


def main() -> None:
    argv = sys.argv[1:]
    port = 0
    if "--port" in argv:
        try:
            port = int(argv[argv.index("--port") + 1])
        except (ValueError, IndexError):
            sys.exit("Usage: app.py [--port N] [--no-browser]")
    for d in (BIN_DIR, DATA_DIR, DOWNLOADS_DIR):
        d.mkdir(parents=True, exist_ok=True)
    server = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    server.daemon_threads = True
    port = server.server_address[1]
    server.allowed_hosts = {"127.0.0.1:%d" % port, "localhost:%d" % port}
    server.allowed_origins = {"http://" + h for h in server.allowed_hosts}
    url = "http://127.0.0.1:%d/" % port
    threading.Thread(target=refresh_tool_state, daemon=True).start()
    print("Mnemosyne is running at %s" % url)
    print("Close this window or press Ctrl+C to stop it.")
    if "--no-browser" not in argv:
        threading.Timer(0.5, webbrowser.open, (url,)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        JOBS.shutdown()
        server.server_close()


if __name__ == "__main__":
    main()
