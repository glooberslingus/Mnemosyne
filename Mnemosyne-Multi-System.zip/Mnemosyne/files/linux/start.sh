#!/usr/bin/env bash
# Starts Mnemosyne on Linux (run by Start-Linux.sh). Installs nothing.
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APP="$HERE/../app/mnemosyne.py"

[ -f "$APP" ] || { echo "Couldn't find files/app/mnemosyne.py. Please extract the whole zip first, then try again." >&2; exit 1; }

PY=""
for c in python3 python; do
    if command -v "$c" >/dev/null 2>&1 && "$c" -c 'import sys; sys.exit(0 if sys.version_info >= (3, 9) else 1)' 2>/dev/null; then
        PY="$(command -v "$c")"; break
    fi
done
if [ -z "$PY" ]; then
    hint="Install Python 3.9+ with your package manager, then run this again."
    if   command -v apt-get >/dev/null 2>&1; then hint="Install it with:  sudo apt install python3"
    elif command -v dnf     >/dev/null 2>&1; then hint="Install it with:  sudo dnf install python3"
    elif command -v pacman  >/dev/null 2>&1; then hint="Install it with:  sudo pacman -S python"
    elif command -v zypper  >/dev/null 2>&1; then hint="Install it with:  sudo zypper install python3"
    fi
    echo "Python 3.9 or newer wasn't found. $hint" >&2
    exit 1
fi

exec "$PY" "$APP" "$@"
