#!/usr/bin/env bash
# Starts Mnemosyne on macOS (run by Start-macOS.command). Installs nothing.
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APP="$HERE/../app/mnemosyne.py"

[ -f "$APP" ] || { echo "Couldn't find files/app/mnemosyne.py. Please extract the whole zip first, then try again." >&2; exit 1; }

find_python() {
    local c
    for c in /opt/homebrew/bin/python3 /usr/local/bin/python3 \
             /Library/Frameworks/Python.framework/Versions/Current/bin/python3 \
             "$(command -v python3 2>/dev/null)"; do
        [ -n "$c" ] && [ -x "$c" ] || continue
        # /usr/bin/python3 is a stub that opens an installer dialog unless the
        # Command Line Tools are installed, so only trust it when they are.
        if [ "$c" = "/usr/bin/python3" ] && ! xcode-select -p >/dev/null 2>&1; then continue; fi
        if "$c" -c 'import sys; sys.exit(0 if sys.version_info >= (3, 9) else 1)' 2>/dev/null; then
            echo "$c"; return 0
        fi
    done
    return 1
}

PY="$(find_python || true)"
if [ -z "$PY" ]; then
    echo "Python 3.9 or newer wasn't found." >&2
    echo "Install it from https://www.python.org/downloads/macos/ (or run: xcode-select --install)," >&2
    echo "then double-click Start-macOS.command again." >&2
    exit 1
fi

exec "$PY" "$APP" "$@"
